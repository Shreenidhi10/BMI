package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Male extends AppCompatActivity {
SpeedometerView Speed;
Button bt;
TextView age,height,weight;
float bmi=10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_male2);

        bt=findViewById(R.id.button);
        age=findViewById(R.id.age);
        height=findViewById(R.id.height);
        weight=findViewById(R.id.weight);
        Speed = (SpeedometerView)findViewById(R.id.speedometer);
        Speed.setLabelConverter(new SpeedometerView.LabelConverter() {
            @Override
            public String getLabelFor(double progress, double maxProgress) {
                return String.valueOf((int) Math.round(progress));
            }
        });

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String il = height.getText().toString();
                float h = Float.parseFloat(il);
                String in = weight.getText().toString();
                int w=Integer.parseInt(in);
                float hi=h*h;
                bmi=w/(hi);
                Speed.setSpeed(bmi, 2000, 500);
            }
        });
// configure value range and ticks
        Speed.setMaxSpeed(50);
        Speed.setMajorTickStep(5);
        Speed.setMinorTicks(5);

// Configure value range colors

        Speed.addColoredRange(0, 16, Color.RED);
        Speed.addColoredRange(16, 18.5, Color.YELLOW);
        Speed.addColoredRange(18.5, 25, Color.GREEN);
        Speed.addColoredRange(25, 35, Color.YELLOW);
        Speed.addColoredRange(35, 50, Color.RED);

    }
}