package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;

public class MainActivity2 extends AppCompatActivity {
ImageButton imageButton1,imageButton2;
    Animation scaleUp,scaleDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        imageButton2=(ImageButton) findViewById(R.id.imageButton2);
        scaleUp= AnimationUtils.loadAnimation(this,R.anim.scale_up);
        scaleDown= AnimationUtils.loadAnimation(this,R.anim.scale_down);

        imageButton2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    imageButton2.startAnimation(scaleUp);
                    openMale();
                } else if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    imageButton2.startAnimation(scaleDown);
                    openMale();
                }

                return true;
            }
        });

        imageButton1=(ImageButton) findViewById(R.id.imageButton1);
        scaleUp= AnimationUtils.loadAnimation(this,R.anim.scale_up);
        scaleDown= AnimationUtils.loadAnimation(this,R.anim.scale_down);

        imageButton1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    imageButton1.startAnimation(scaleUp);
                    openMale();
                } else if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    imageButton1.startAnimation(scaleDown);
                    openMale();
                }

                return true;
            }
        });
    }
    public void openMale(){
        Intent intent=new Intent(this,Male.class);
        startActivity(intent);
    }
    public void openFemale(){
        Intent intent=new Intent(this,Female.class);
        startActivity(intent);
    }
}